ALDI CROPTOP - tampilan futuristik dengan logo foto pengguna

Perubahan:
- Tombol floating dibuat alpha 0.38 (lebih pudar).
- Tombol dapat digeser ke posisi yang diinginkan.
- Ketuk tombol untuk mengambil layar, lalu pilih area soal.
- Area crop dikirim ke Gemini untuk dianalisis.

Cara membuka:
1. Ekstrak ZIP.
2. Buka folder Sanadoy_Croptop melalui Android Studio.
3. Tunggu Gradle selesai melakukan sinkronisasi.
4. Jalankan Build > Build APK(s).
5. APK debug akan berada di app/build/outputs/apk/debug/app-debug.apk.

Cara menggunakan:
1. Buka aplikasi dan masukkan Gemini API Key.
2. Tekan AKTIFKAN TOMBOL FLOATING.
3. Izinkan tampil di atas aplikasi lain dan izin berbagi layar.
4. Tombol transparan akan muncul. Buka halaman yang ingin dicrop.
5. Geser tombol bila perlu, lalu ketuk untuk menangkap layar.
6. Tandai area soal dan tekan KIRIM KE GEMINI.

Catatan:
- Proyek ini memerlukan Android Studio/Android SDK untuk dikompilasi menjadi APK.
- API Key Gemini disimpan pada preferensi lokal aplikasi. Jangan membagikan APK yang berisi kredensial pribadi.
- Android akan menampilkan notifikasi saat screen capture aktif. Pengambilan layar hanya berjalan setelah pengguna memberi izin sistem.

Pembaruan tampilan:
- Nama launcher: Aldi Croptop.
- Ikon aplikasi memakai foto yang diberikan.
- Tema gelap futuristik dengan aksen cyan dan ungu.
- Tombol floating tetap transparan 38%.
