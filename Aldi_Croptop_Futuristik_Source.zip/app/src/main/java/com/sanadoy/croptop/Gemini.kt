package com.sanadoy.croptop

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

object Gemini {
    private fun call(key: String, body: JSONObject, model: String): Pair<Int, String> {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key")
            .openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.requestMethod = "POST"
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val txt = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        return Pair(c.responseCode, txt)
    }

    fun ask(key: String, bmp: Bitmap, cb: (String) -> Unit) {
        thread {
            val out = try {
                val scale = minOf(1f, 1024f / maxOf(bmp.width, bmp.height))
                val small = if (scale < 1f) Bitmap.createScaledBitmap(
                    bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true
                ) else bmp
                val bo = ByteArrayOutputStream()
                small.compress(Bitmap.CompressFormat.JPEG, 80, bo)
                val b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
                val parts = JSONArray()
                    .put(JSONObject().put("text", "Bantu pahami dan jawab soal pada gambar. Berikan jawaban akhir dan penjelasan singkat dalam bahasa Indonesia."))
                    .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
                    .put("generationConfig", JSONObject().put("maxOutputTokens", 800))
                var result = Pair(0, "")
                loop@ for (model in listOf("gemini-flash-latest", "gemini-flash-lite-latest")) {
                    result = call(key, body, model)
                    if (result.first !in listOf(429, 500, 503)) break@loop
                }
                if (result.first !in 200..299) "Error ${result.first}: ${result.second}"
                else JSONObject(result.second).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            } catch (e: Exception) { "Gagal: ${e.message}" }
            cb(out)
        }
    }
}
