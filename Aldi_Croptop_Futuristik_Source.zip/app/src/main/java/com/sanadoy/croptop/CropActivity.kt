package com.sanadoy.croptop

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class CropActivity : AppCompatActivity() {
    private lateinit var cropView: CropView
    private lateinit var result: TextView
    private lateinit var progress: ProgressBar
    private var original: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val path = intent.getStringExtra("image_path")
        original = BitmapFactory.decodeFile(path)
        if (original == null) { finish(); return }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(8, 13, 27))
        }
        val hint = TextView(this).apply {
            text = "ALDI CROPTOP  •  PILIH AREA SOAL"
            setTextColor(Color.rgb(72, 229, 255)); textSize = 15f
        }
        cropView = CropView().apply { setImage(original!!) }
        val send = Button(this).apply { text = "KIRIM KE GEMINI" }
        progress = ProgressBar(this).apply { visibility = View.GONE }
        result = TextView(this).apply { text = "Pilih area soal, lalu tekan tombol."; setTextColor(Color.WHITE); textSize = 16f }
        val scroll = ScrollView(this).apply { addView(result) }
        root.addView(hint)
        root.addView(cropView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(send)
        root.addView(progress)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        send.setOnClickListener {
            val selected = cropView.cropped()
            if (selected == null) {
                Toast.makeText(this, "Pilih area soal terlebih dahulu.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val key = getSharedPreferences("p", MODE_PRIVATE).getString("key", "").orEmpty()
            if (key.isBlank()) { result.text = "API Key Gemini belum diisi. Kembali ke aplikasi dan masukkan API Key."; return@setOnClickListener }
            progress.visibility = View.VISIBLE
            result.text = "Sedang membaca gambar..."
            Gemini.ask(key, selected) { answer ->
                runOnUiThread {
                    progress.visibility = View.GONE
                    result.text = answer
                    selected.recycle()
                }
            }
        }
    }

    override fun onDestroy() {
        original?.recycle()
        super.onDestroy()
    }

    private inner class CropView : View(this@CropActivity) {
        private var bitmap: Bitmap? = null
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var scale = 1f
        private var offsetX = 0f
        private var offsetY = 0f
        private var x1 = 0f; private var y1 = 0f; private var x2 = 0f; private var y2 = 0f
        private var selected = false

        fun setImage(b: Bitmap) { bitmap = b; invalidate() }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val b = bitmap ?: return
            scale = minOf(width.toFloat() / b.width, height.toFloat() / b.height)
            offsetX = (width - b.width * scale) / 2f
            offsetY = (height - b.height * scale) / 2f
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(b, null, RectF(offsetX, offsetY, offsetX + b.width * scale, offsetY + b.height * scale), paint)
            if (selected) {
                paint.color = 0x5533B5E5
                canvas.drawRect(minOf(x1, x2), minOf(y1, y2), maxOf(x1, x2), maxOf(y1, y2), paint)
                paint.color = Color.GREEN; paint.style = Paint.Style.STROKE; paint.strokeWidth = 4f
                canvas.drawRect(minOf(x1, x2), minOf(y1, y2), maxOf(x1, x2), maxOf(y1, y2), paint)
                paint.style = Paint.Style.FILL; paint.color = Color.WHITE
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { x1 = event.x; y1 = event.y; x2 = x1; y2 = y1; selected = true; invalidate(); return true }
                MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> { x2 = event.x; y2 = event.y; invalidate(); return true }
            }
            return true
        }

        fun cropped(): Bitmap? {
            val b = bitmap ?: return null
            if (!selected || scale <= 0f) return null
            val left = (((minOf(x1, x2) - offsetX) / scale).toInt()).coerceIn(0, b.width)
            val top = (((minOf(y1, y2) - offsetY) / scale).toInt()).coerceIn(0, b.height)
            val right = (((maxOf(x1, x2) - offsetX) / scale).toInt()).coerceIn(0, b.width)
            val bottom = (((maxOf(y1, y2) - offsetY) / scale).toInt()).coerceIn(0, b.height)
            if (right - left < 20 || bottom - top < 20) return null
            return Bitmap.createBitmap(b, left, top, right - left, bottom - top)
        }
    }
}
