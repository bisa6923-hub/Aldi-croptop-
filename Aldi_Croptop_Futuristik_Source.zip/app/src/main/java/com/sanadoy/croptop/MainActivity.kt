package com.sanadoy.croptop

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.yalantis.ucrop.UCrop
import java.io.File

class MainActivity : AppCompatActivity() {
    private val PICK = 1
    private lateinit var apiKey: EditText
    private lateinit var preview: ImageView
    private lateinit var answer: TextView
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        apiKey = findViewById(R.id.apiKey)
        preview = findViewById(R.id.preview)
        answer = findViewById(R.id.answer)
        progress = findViewById(R.id.progress)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        apiKey.setText(prefs.getString("key", ""))

        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            prefs.edit().putString("key", apiKey.text.toString().trim()).apply()
            if (apiKey.text.toString().trim().isEmpty()) {
                apiKey.error = "Masukkan Gemini API Key terlebih dahulu"
                return@setOnClickListener
            }
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan Tampil di atas aplikasi lain, lalu kembali.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 3)
            }
            val manager = getSystemService(MediaProjectionManager::class.java)
            startActivityForResult(manager.createScreenCaptureIntent(), 2)
        }

        findViewById<Button>(R.id.btnPick).setOnClickListener {
            prefs.edit().putString("key", apiKey.text.toString().trim()).apply()
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), PICK)
        }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != Activity.RESULT_OK || data == null) return
        if (req == 2) {
            val service = Intent(this, OverlayService::class.java)
                .putExtra("code", res).putExtra("data", data)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            moveTaskToBack(true)
        } else if (req == PICK) {
            val dest = Uri.fromFile(File(cacheDir, "crop_${System.currentTimeMillis()}.jpg"))
            UCrop.of(data.data!!, dest).withMaxResultSize(1600, 1600).start(this)
        } else if (req == UCrop.REQUEST_CROP) {
            val uri = UCrop.getOutput(data) ?: return
            val bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(uri)) ?: return
            preview.setImageBitmap(bmp)
            runGemini(bmp)
        }
    }

    private fun runGemini(bmp: Bitmap) {
        val key = apiKey.text.toString().trim()
        if (key.isEmpty()) { answer.text = "Isi API key terlebih dahulu."; return }
        progress.visibility = View.VISIBLE
        answer.text = ""
        Gemini.ask(key, bmp) { result ->
            runOnUiThread {
                progress.visibility = View.GONE
                answer.text = result
            }
        }
    }
}
