package com.sanadoy.croptop

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var worker: Handler? = null
    private var params: WindowManager.LayoutParams? = null
    private var busy = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java)
                   else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        try {
            val thread = HandlerThread("SanadoyCapture").also { it.start() }
            worker = Handler(thread.looper)
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            val p = projection ?: run { stopSelf(); return START_NOT_STICKY }
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { cleanup(); stopSelf() }
            }, worker)

            val metrics = resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
            display = p.createVirtualDisplay(
                "Sanadoy Croptop Screen", width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, worker
            )
            showBubble()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal mengaktifkan floating: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channel = "sanadoy_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(channel, "Sanadoy screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channel).setContentTitle("Sanadoy Croptop")
                .setContentText("Tombol crop layar sedang aktif")
                .setSmallIcon(android.R.drawable.ic_menu_camera).build()
        else Notification.Builder(this).setContentTitle("Sanadoy Croptop")
            .setContentText("Tombol crop layar sedang aktif")
            .setSmallIcon(android.R.drawable.ic_menu_camera).build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(21, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(21, n)
    }

    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = TextView(this).apply {
            text = "✂"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC6759E8.toInt())
                setStroke(2, 0x88FFFFFF.toInt())
            }
            alpha = 0.38f // tombol floating lebih pudar/transparan
            elevation = 10f
            contentDescription = "Sanadoy crop layar"
        }
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            dp(54), dp(54), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - dp(70)
            y = resources.displayMetrics.heightPixels / 3
        }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        v.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = event.rawX; touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(5)) moved = true
                    lp.x = startX + dx; lp.y = startY + dy
                    wm.updateViewLayout(v, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) captureAndOpen()
                    true
                }
                else -> true
            }
        }
        bubble = v
        params = lp
        wm.addView(v, lp)
    }

    private fun captureAndOpen() {
        if (busy) return
        busy = true
        val view = bubble
        view?.visibility = View.INVISIBLE
        // Tunggu satu frame agar tombol tidak ikut masuk ke hasil tangkapan layar.
        worker?.postDelayed({
            try {
                val image: Image? = reader?.acquireLatestImage()
                if (image == null) {
                    busy = false
                    view?.visibility = View.VISIBLE
                    return@postDelayed
                }
                val bitmap = imageToBitmap(image)
                image.close()
                val file = File(cacheDir, "screen_${System.currentTimeMillis()}.png")
                FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bitmap.recycle()
                val open = Intent(this, CropActivity::class.java)
                    .putExtra("image_path", file.absolutePath)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(open)
                // Sembunyikan tombol sampai pengguna kembali ke layar utama aplikasi.
                stopSelf()
            } catch (e: Exception) {
                busy = false
                view?.visibility = View.VISIBLE
                android.os.Handler(mainLooper).post {
                    Toast.makeText(this, "Gagal mengambil layar: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }, 350)
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val paddedWidth = rowStride / pixelStride
        val full = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        val crop: Rect = image.cropRect
        val result = Bitmap.createBitmap(full, crop.left, crop.top, crop.width(), crop.height())
        full.recycle()
        return result
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun cleanup() {
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        bubble = null
        try { display?.release() } catch (_: Exception) {}
        display = null
        try { reader?.close() } catch (_: Exception) {}
        reader = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
